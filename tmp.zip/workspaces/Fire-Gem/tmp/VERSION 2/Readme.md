bot.standarc.c
